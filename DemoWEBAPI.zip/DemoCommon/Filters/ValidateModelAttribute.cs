﻿using Microsoft.AspNetCore.Mvc.Filters;
using System.Net;

namespace DemoCommon.Filters
{
    /// <summary>
    /// ValidateModelAttribute this class is used for validating the model class object
    /// </summary>
    public class ValidateModelAttribute : ActionFilterAttribute
    {
        /// <summary>
        /// OnActionExecuting
        /// </summary>
        /// <param name="context"></param>
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (!context.ModelState.IsValid)
            {
                context.Result = new ValidationFailedResult(context.ModelState);
            }
        }
    }
}
