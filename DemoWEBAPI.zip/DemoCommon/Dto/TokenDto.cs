﻿using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Text;

namespace DemoCommon.Dto
{
    public class TokenDto
    {
        public string AccessToken { get; set; }

        public IEnumerable<Claim> Claims { get; set; }

        public string RefreshToken { get; set; }

        public Guid Serialnumber { get; set; }

        public Guid RefreshtokenidHashsource { get; set; }

        public Guid UserId { get; set; }

        public string UserFullName { get; set; }
    }

}
