﻿using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Text;

namespace DemoCommon.Dto
{
    public class UserTokenDto
    {
        public Guid Id { get; set; }

        public string AccessTokenHash { get; set; }

        // public DateTimeOffset AccessTokenExpiresDateTime { get; set //SonarQube Complaint
        public DateTime AccessTokenExpiresDateTime { get; set; }

        public string RefreshTokenIdHash { get; set; }
        public Guid SerialNumber { get; set; }

        public string RefreshTokenIdHashSource { get; set; }

        //public DateTimeOffset RefreshTokenExpiresDateTime { get; set //SonarQube Complaint
        public DateTime RefreshTokenExpiresDateTime { get; set; }

        public Guid UserId { get; set; }

    }
}
