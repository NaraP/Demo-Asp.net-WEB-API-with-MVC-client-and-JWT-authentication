﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DemoCommon.Dto
{
   public  class UserDto
    {
        public Guid UserId { get; set; }
        [Required, MaxLength(50)]
        public string UserName { get; set; }
        [Required, MaxLength(50)]
        [RegularExpression(@"^[a-zA-Z0-9 ]+$")]
        public string FirstName { get; set; }
        [Required, MaxLength(50)]
        [RegularExpression(@"^[a-zA-Z0-9 ]+$")]
        public string SurName { get; set; }
        [Required, MaxLength(50)]
        [RegularExpression(@"^[a-zA-Z0-9 ]+$")]
        public string Employer { get; set; }
        [Required, MaxLength(50)]
        [RegularExpression(@"^[a-zA-Z0-9 ]+$")]
        public string JobPosition { get; set; }
        [Required, MaxLength(50)]
        [EmailAddress]
        public string EmailId { get; set; }

        public decimal? HourlyRate { get; set; }
        public bool? EnableSkill { get; set; }
        public decimal? PerfRating { get; set; }

        public Guid SerialNumber { get; set; }
        public string Password { get; set; }
        public string FullName { get; set; }
        public bool IsSystemRole { get; set; }

        public bool? IsActive { get; set; }

        public String RefreshtokenidHashsource { get; set; }
        public ICollection<UserRolesCommonDto> UserRolesDtoList { get; set; }
        public UserPriviledgesDto UserPriviledges { get; set; }
    }
}
    