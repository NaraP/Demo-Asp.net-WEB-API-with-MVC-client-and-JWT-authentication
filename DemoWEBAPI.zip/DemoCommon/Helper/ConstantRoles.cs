﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DemoCommon.Helper
{
   public static class PermissionUserRoles
    {
        public const string Edit = "Edit";
        public const string View = "View";

        public const string Hide = "Hide";

        public const string SkillsEdit = "SkillsEdit";
        public const string SkillsView = "SkillsView";

        public const string UnauthorizedAccess = "Unauthorized Access";
        public const string ServerError = "A server error occurred.";

        public const string JsonResponse = "application/json";
    }
}
