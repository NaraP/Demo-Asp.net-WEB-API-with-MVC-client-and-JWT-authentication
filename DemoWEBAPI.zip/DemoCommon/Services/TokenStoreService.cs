﻿using DemoCommon.Dto;
using DemoCommon.IServices;
using DemoCommon.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace DemoCommon.Services
{
    public class TokenStoreService : ITokenStoreService
    {
        private readonly IOptionsSnapshot<BearerTokensOptions> _configuration;
        private readonly IUserAuthService _userService;
        private readonly ISecurityService _securityService;
        private readonly TestDemoContext _testDemoContext ;

        private readonly DbSet<UserToken> _UserTokens;

        /// <summary>
        /// TokenStoreService
        /// </summary>
        /// <param name="configuration"></param>
        /// <param name="userService"></param>
        /// <param name="securityService"></param>
        public TokenStoreService(IOptionsSnapshot<BearerTokensOptions> configuration, IUserAuthService userService, ISecurityService securityService, TestDemoContext testDemoContext)
        {
            _configuration = configuration;
            _userService = userService;
            _securityService = securityService;
            _testDemoContext = testDemoContext;
            _UserTokens = _testDemoContext.Set<UserToken>();
        }

        /// <summary>
        /// CreateJwtTokens
        /// </summary>
        /// <param name="user"></param>
        /// <param name="refreshTokenSource"></param>
        /// <returns></returns>
        public async Task<TokenDto> CreateJwtTokens(UserDto user, string refreshTokenSource)
        {
            var result = CreateAccessTokenAsync(user).GetAwaiter().GetResult();
            var refreshToken = Guid.NewGuid().ToString().Replace("-", "");
            await _userService.AddUserTokenAsync(user, refreshToken, result.AccessToken, refreshTokenSource);
            return await Task.FromResult<TokenDto>(new TokenDto { AccessToken = result.AccessToken, Claims = result.Claims, RefreshToken = refreshToken, Serialnumber = user.SerialNumber, UserId = user.UserId, UserFullName = user.FullName});
        }

        /// <summary>
        /// createAccessTokenAsync
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        private async Task<TokenDto> CreateAccessTokenAsync(UserDto user)
        {
            var claims = new List<Claim>
            {
                // Unique Id for all Jwt tokes
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString(), ClaimValueTypes.String, _configuration.Value.Issuer),
                // Issuer
                new Claim(JwtRegisteredClaimNames.Iss, _configuration.Value.Issuer, ClaimValueTypes.String, _configuration.Value.Issuer),
                // Issued at
                new Claim(JwtRegisteredClaimNames.Iat, DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString(), ClaimValueTypes.Integer64, _configuration.Value.Issuer),
                new Claim(ClaimTypes.Email, user.EmailId.ToString(), ClaimValueTypes.String, _configuration.Value.Issuer),
                new Claim(ClaimTypes.Name, user.UserName, ClaimValueTypes.String, _configuration.Value.Issuer),
                // to invalidate the cookie
                new Claim(ClaimTypes.SerialNumber, user.SerialNumber.ToString(), ClaimValueTypes.String, _configuration.Value.Issuer),
                // custom data
                new Claim(ClaimTypes.UserData, user.UserId.ToString(), ClaimValueTypes.String, _configuration.Value.Issuer)
            };

            // add roles
            var priviledges = user.UserPriviledges.Priviledges.ToArray();

            foreach (var priviledge in priviledges)
            {
                if (!claims.Where(x => x.Value.ToString().Equals(priviledge)).Any())// Not adding duplicate privileges
                {
                    claims.Add(new Claim(priviledge, priviledge, ClaimValueTypes.String, _configuration.Value.Issuer));
                }
            }


            var allRoles = user.UserRolesDtoList;

            if (allRoles != null)
            {
                foreach (var role in allRoles)
                {
                    claims.Add(new Claim(ClaimTypes.Role, role.RoleDto.Rolename, ClaimValueTypes.String, _configuration.Value.Issuer));
                }
            }


            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration.Value.Key));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var now = DateTime.UtcNow;

            var token = new JwtSecurityToken(
                issuer: _configuration.Value.Issuer,
                audience: _configuration.Value.Audience,
                claims: claims,
                notBefore: now,
                expires: now.AddMinutes(_configuration.Value.AccessTokenExpirationMinutes),
                signingCredentials: creds);

            return await Task.FromResult<TokenDto>(new TokenDto { AccessToken = new JwtSecurityTokenHandler().WriteToken(token), Claims = claims });
        }

        /// <summary>
        /// DeleteExpiredTokensAsync
        /// </summary>
        /// <returns></returns>
        public async Task DeleteExpiredTokensAsync()
        {
            var now = DateTimeOffset.UtcNow.AddMinutes(6);

            await _UserTokens.Where(x => x.RefreshTokenExpiresTs < now)
                         .ForEachAsync(userToken =>
                         {
                             _UserTokens.Remove(userToken);
                         });
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="refreshToken"></param>
        /// <param name="userid"></param>
        /// <returns></returns>

        //SolarQube Non compliance
        /*
        public async Task DeleteTokenAsync(string refreshToken, Guid userid)
        {
            var token = await _UserTokens.FirstOrDefaultAsync(u => u.RefreshTokenIdHash == refreshToken && u.UserId == userid).ConfigureAwait(false);//   FindTokenAsync(refreshToken, userid);
            if (token != null)
            {
               _UserTokens.Remove(token);
            }
        }
        */

        //SolarQube compliance
        public async Task DeleteTokenAsync(string refreshToken, Guid userId)
        {
            var token = await _UserTokens.FirstOrDefaultAsync(u => u.RefreshTokenIdHash == refreshToken && u.UserId == userId).ConfigureAwait(false);//   FindTokenAsync(refreshToken, userid);
            if (token != null)
            {
                _UserTokens.Remove(token);
            }
        }

        /// <summary>
        /// DeleteTokensWithSameRefreshTokenSourceAsync
        /// </summary>
        /// <param name="refreshTokenIdHashSource"></param>
        /// <returns></returns>
        public async Task DeleteTokensWithSameRefreshTokenSourceAsync(string refreshTokenIdHashSource)
        {
            if (string.IsNullOrWhiteSpace(refreshTokenIdHashSource))
            {
                return;
            }
            var token = await _UserTokens.FirstOrDefaultAsync(u => u.RefreshTokenIdHash == refreshTokenIdHashSource).ConfigureAwait(false);//   FindTokenAsync(refreshToken, userid);

            if (token != null)
            {
                //_UserTokens.Remove(token)
                _testDemoContext.UserToken.Remove(token);
            }
            //await _UserTokens.Where(t => t.RefreshTokenIdHashSource == refreshTokenIdHashSource)
            //             .ForEachAsync(userToken =>
            //             
            //                 _UserTokens.Remove(userToken)
            //             })
        }

        /// <summary>
        /// RevokeUserBearerTokensAsync
        /// </summary>
        /// <param name="userIdValue"></param>
        /// <param name="refreshToken"></param>
        /// <returns></returns>
        public async Task RevokeUserBearerTokensAsync(string userIdValue, string refreshToken)
        {
            if (!string.IsNullOrWhiteSpace(userIdValue) && Guid.TryParse(userIdValue, out Guid userId) && _configuration.Value.AllowSignoutAllUserActiveClients)
            {
                await InvalidateUserTokensAsync(Guid.Parse(userIdValue));

            }

            if (!string.IsNullOrWhiteSpace(refreshToken))
            {
                var refreshTokenIdHashSource = _securityService.GetSha256Hash(refreshToken);
                await DeleteTokensWithSameRefreshTokenSourceAsync(refreshTokenIdHashSource);
            }

            //await DeleteExpiredTokensAsync()

            await _testDemoContext.SaveChangesAsync();
        }

        /// <summary>
        /// FindTokenAsync
        /// </summary>
        /// <param name="refreshToken"></param>
        /// <param name="userid"></param>
        /// <returns></returns>
        public async Task<UserDto> FindTokenAsync(string refreshToken, Guid userId)  
        {
            if (string.IsNullOrWhiteSpace(refreshToken))
            {
                return null;
            }
            var refreshTokenIdHash = _securityService.GetSha256Hash(refreshToken);

            var userToken = await _UserTokens.Include(x => x.User)
                 .ThenInclude(y => y.UserRole)
            .ThenInclude(z => z.Role)
            .ThenInclude(z => z.RolePrivilegeSecurable)
            .ThenInclude(p => p.Privilege)
            .ThenInclude(z => z.RolePrivilegeSecurable)
            .ThenInclude(k => k.Securable).SingleOrDefaultAsync(x => x.RefreshTokenIdHash == refreshTokenIdHash && x.UserId == userId && DateTime.Now.ToUniversalTime() <= x.RefreshTokenExpiresTs.Value).ConfigureAwait(false);

            if (userToken == null)
            {
                return null;
            }
            else
                return Mapper.CommonMapper.UserToUserDto(userToken.User);
        }

        /// <summary>
        /// InvalidateUserTokensAsync
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task InvalidateUserTokensAsync(Guid userId)
        {
            await _UserTokens.Where(x => x.UserId == userId)
                         .ForEachAsync(userToken =>
                         {
                             _UserTokens.Remove(userToken);
                         });
        }

        /// <summary>
        /// IsValidTokenAsync
        /// </summary>
        /// <param name="accessToken"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task<bool> IsValidTokenAsync(string accessToken, Guid userId)
        {
            var accessTokenHash = _securityService.GetSha256Hash(accessToken);
            var userToken = await _UserTokens.FirstOrDefaultAsync(
                x => x.AccessTokenHash == accessTokenHash && x.UserId == userId);
            return userToken?.AccessTokenExpiresTs >= DateTimeOffset.UtcNow;
        }
    }

}
