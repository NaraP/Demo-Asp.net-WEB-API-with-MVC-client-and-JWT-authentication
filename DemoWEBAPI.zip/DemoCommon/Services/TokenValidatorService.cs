﻿using DemoCommon.Extensions;
using DemoCommon.IServices;
using DemoCommon.Models;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace DemoCommon.Services
{
    /// <summary>
    /// TokenValidatorService
    /// </summary>
    public class TokenValidatorService : ITokenValidatorService
    {
        private readonly IUserAuthService _usersService;
        // private readonly ITokenStoreService _tokenStoreService //SonarQube Non Compliance
        private readonly ISecurityService _securityService;
        private readonly TestDemoContext _testDemoContext;
        // UsersCommonDto userDto = null //SonarQube Non Complaince

        /// <summary>
        /// TokenValidatorService
        /// </summary>
        /// <param name="usersService"></param>
        /// <param name="tokenStoreService"></param>
        /// <param name="securityService"></param>
        /// <param name="abbRcsContext"></param>
        public TokenValidatorService(IUserAuthService usersService, ITokenStoreService tokenStoreService,
            ISecurityService securityService, TestDemoContext testDemoContext)
        {
            ITokenStoreService _tokenStoreService; //SonarQube Complaince
            //UsersCommonDto userDto = null; //SonarQube Non compliance
            _usersService = usersService;
            _usersService.CheckArgumentIsNull(nameof(usersService));
            _testDemoContext = testDemoContext;
            _tokenStoreService = tokenStoreService;
            _securityService = securityService;
            _tokenStoreService.CheckArgumentIsNull(nameof(_tokenStoreService));

            //  userDto = new UsersCommonDto() SonarQube Complaint..
        }

        /// <summary>
        /// ValidateAsync
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task ValidateAsync(TokenValidatedContext context)
        {
            //SonarQube Non compliance
            //var userPrincipal = context.Principal;

            var claimsIdentity = context.Principal.Identity as ClaimsIdentity;
            if (claimsIdentity?.Claims == null || !claimsIdentity.Claims.Any())
            {
                context.Fail("This is not our issued token. It has no claims.");
                return;
            }

            var serialNumberClaim = claimsIdentity.FindFirst(ClaimTypes.SerialNumber);
            if (serialNumberClaim == null)
            {
                context.Fail("This is not our issued token. It has no serial.");
                return;
            }

            var userIdString = claimsIdentity.FindFirst(ClaimTypes.UserData).Value;
            if (!Guid.TryParse(userIdString, out Guid userId))
            {
                context.Fail("This is not our issued token. It has no user-id.");
                return;
            }

            //commented for single user logged in for single project.

            var user = await _usersService.FindUserAsyncById(userId);

            if (user == null || user.SerialNumber.ToString() != serialNumberClaim.Value || (user.IsActive.HasValue && user.IsActive.Value))
            {
                // user has changed his/her password/roles/stat/IsActive
                //context.Fail("Your privileges seems to be modified. Please re-login to continue working with new privileges.");
                context.Response.Headers.Add("Your privileges seems to be modified. Please re-login to continue working with new privileges.", "true");
                return;
            }

            var accessToken = context.SecurityToken as JwtSecurityToken;
            if (accessToken == null || string.IsNullOrWhiteSpace(accessToken.RawData) ||
                !await IsValidTokenAsync(accessToken.RawData, userId))
            {
                context.Fail("This token is not in our database.");
                return;
            }

            await _usersService.UpdateUserLastActivityDateAsync(userId);
        }

        /// <summary>
        /// IsValidTokenAsync
        /// </summary>
        /// <param name="accessToken"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task<bool> IsValidTokenAsync(string accessToken, Guid userId)
        {
            var accessTokenHash = _securityService.GetSha256Hash(accessToken);
            var userToken = await _testDemoContext.UserToken.FirstOrDefaultAsync(
                x => x.AccessTokenHash == accessTokenHash && x.UserId == userId);
            return userToken?.AccessTokenExpiresTs >= DateTime.UtcNow;
        }
    }
}
