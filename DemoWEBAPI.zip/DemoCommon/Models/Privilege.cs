﻿using System;
using System.Collections.Generic;

namespace DemoCommon.Models
{
    public partial class Privilege
    {
        public Privilege()
        {
            RolePrivilegeSecurable = new HashSet<RolePrivilegeSecurable>();
        }

        public Guid PrivilegeId { get; set; }
        public string PrivilegeName { get; set; }
        public string PrivilegeDesc { get; set; }
        public bool? IsActive { get; set; }
        public Guid CreateUser { get; set; }
        public DateTime CreateTs { get; set; }
        public Guid UpdateUser { get; set; }
        public DateTime UpdateTs { get; set; }

        public virtual ICollection<RolePrivilegeSecurable> RolePrivilegeSecurable { get; set; }
    }
}
