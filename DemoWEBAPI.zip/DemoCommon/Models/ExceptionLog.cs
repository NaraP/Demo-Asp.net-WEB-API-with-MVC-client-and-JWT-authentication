﻿using System;
using System.Collections.Generic;

namespace DemoCommon.Models
{
    public partial class ExceptionLog
    {
        public Guid ExceptionId { get; set; }
        public string ExceptionMsg { get; set; }
        public string ExceptionType { get; set; }
        public string ExceptionSource { get; set; }
        public string ExceptionUrl { get; set; }
        public string RemoteIpAddr { get; set; }
        public string ControllerName { get; set; }
        public string ActionName { get; set; }
        public DateTime ExceptionTs { get; set; }
        public Guid CreateUser { get; set; }
        public DateTime CreateTs { get; set; }
    }
}
