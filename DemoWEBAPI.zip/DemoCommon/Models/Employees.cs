﻿using System;
using System.Collections.Generic;

namespace DemoCommon.Models
{
    public partial class Employees
    {
        public Guid EmpId { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string Gender { get; set; }
        public string Company { get; set; }
        public string Designation { get; set; }
        public bool? IsActive { get; set; }
        public Guid CreateUser { get; set; }
        public DateTime CreateTs { get; set; }
        public Guid UpdateUser { get; set; }
        public DateTime UpdateTs { get; set; }

        public object MapSkillToSkillDto(Employees emps)
        {
            throw new NotImplementedException();
        }
    }
}
