﻿using DemoCommon.Dto;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DemoCommon.IServices
{
    public interface ITokenStoreService
    {
        Task<TokenDto> CreateJwtTokens(UserDto user, string refreshTokenSource);

        Task<bool> IsValidTokenAsync(string accessToken, Guid userId);
        Task DeleteExpiredTokensAsync();
        Task<UserDto> FindTokenAsync(string refreshToken, Guid userId);
        Task DeleteTokenAsync(string refreshToken, Guid userId);
        Task DeleteTokensWithSameRefreshTokenSourceAsync(string refreshTokenIdHashSource);
        Task InvalidateUserTokensAsync(Guid userId);
        Task RevokeUserBearerTokensAsync(string userIdValue, string refreshToken);
    }
}
