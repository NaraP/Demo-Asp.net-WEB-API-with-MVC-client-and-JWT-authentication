﻿using DemoCommon.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DemoCommon.IServices
{
    public interface IGlobalExceptionLogging
    {
        void SaveGlobalExceptionLogging(ExceptionLog exceptionLog);
    }
}
