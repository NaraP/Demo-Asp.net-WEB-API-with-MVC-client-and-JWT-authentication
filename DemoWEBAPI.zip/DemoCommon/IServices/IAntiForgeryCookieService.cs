﻿using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Text;

namespace DemoCommon.IServices
{
    public interface IAntiForgeryCookieService
    {
        void RegenerateAntiForgeryCookies(IEnumerable<Claim> claims);
        void DeleteAntiForgeryCookies();
    }
}
