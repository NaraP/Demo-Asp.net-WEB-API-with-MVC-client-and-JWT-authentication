﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using DemoCommon.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace DemoMVC.Controllers
{
    public class EmployeesController : Controller
    {

        IConfigurationRoot configHelper = ConfigHelper.GetConnectionSection();

        public async Task<ActionResult> Index()
        {
            IEnumerable<Employees> employees = null;

            using (var client = new HttpClient())
            {
                var baseUrl = configHelper["apiBaseAddress"];

                client.BaseAddress = new Uri(baseUrl);

                var result = await client.GetAsync("employees/Get");

                if (result.IsSuccessStatusCode)
                {
                    employees = await result.Content.ReadAsAsync<IList<Employees>>();
                }
                else
                {
                    employees = Enumerable.Empty<Employees>();
                    ModelState.AddModelError(string.Empty, "Server error try after some time.");
                }
            }
            return View(employees);
        }

        public async Task<ActionResult> Details(string id)
        {
            if (id == null)
            {
                return null;
            }

            Employees employee = null;
            using (var client = new HttpClient())
            {
                var baseUrl = configHelper["apiBaseAddress"];

                client.BaseAddress = new Uri(baseUrl);

                var result = await client.GetAsync($"employees/details/{id}");

                if (result.IsSuccessStatusCode)
                {
                    employee = await result.Content.ReadAsAsync<Employees>();
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Server error try after some time.");
                }
            }

            if (employee == null)
            {
               // return HttpNotFound();
            }
            return View(employee);
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(Employees employee)
        {
            if (ModelState.IsValid)
            {
                using (var client = new HttpClient())
                {
                    var baseUrl = configHelper["apiBaseAddress"];

                    client.BaseAddress = new Uri(baseUrl);

                    var response = await client.PostAsJsonAsync("employees/Create", employee);
                    if (response.IsSuccessStatusCode)
                    {
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        ModelState.AddModelError(string.Empty, "Server error try after some time.");
                    }
                }
            }
            return View(employee);
        }

        public async Task<ActionResult> Edit(string id)
        {
            if (id == null)
            {
              //  return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employees employee = null;
            using (var client = new HttpClient())
            {
                var baseUrl = configHelper["apiBaseAddress"];

                client.BaseAddress = new Uri(baseUrl);

                var result = await client.GetAsync($"employees/details/{id}");

                if (result.IsSuccessStatusCode)
                {
                    employee = await result.Content.ReadAsAsync<Employees>();
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Server error try after some time.");
                }
            }
            if (employee == null)
            {
              //  return HttpNotFound();
            }
            return View(employee);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(Employees employee)
        {
            if (ModelState.IsValid)
            {
                using (var client = new HttpClient())
                {
                    var baseUrl = configHelper["apiBaseAddress"];

                    client.BaseAddress = new Uri(baseUrl);
                    var response = await client.PutAsJsonAsync("employees/edit", employee);
                    if (response.IsSuccessStatusCode)
                    {
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        ModelState.AddModelError(string.Empty, "Server error try after some time.");
                    }
                }
                return RedirectToAction("Index");
            }
            return View(employee);
        }

        public async Task<ActionResult> Delete(string id)
        {
            if (id == null)
            {
               // return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employees employee = null;
            using (var client = new HttpClient())
            {
                var baseUrl = configHelper["apiBaseAddress"];

                client.BaseAddress = new Uri(baseUrl);

                var result = await client.GetAsync($"employees/details/{id}");

                if (result.IsSuccessStatusCode)
                {
                    employee = await result.Content.ReadAsAsync<Employees>();
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Server error try after some time.");
                }
            }

            if (employee == null)
            {
               // return HttpNotFound();
            }
            return View(employee);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(string id)
        {
            using (var client = new HttpClient())
            {
                var baseUrl = configHelper["apiBaseAddress"];

                client.BaseAddress = new Uri(baseUrl);

                var response = await client.DeleteAsync($"employees/delete/{id}");
                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }
                else
                    ModelState.AddModelError(string.Empty, "Server error try after some time.");
            }
            return View();
        }
    }
}