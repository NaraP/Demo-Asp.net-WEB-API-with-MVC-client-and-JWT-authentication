﻿using DemoCommon.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JwtMvcCoreCrud.Repository
{
   public interface IEmployeeRepository
    {
        Task<Employees> GetEmployeeById(Guid empId);
        Task<Employees> GetEmployeeByName(Guid empId);
        Task<IList<Employees>> GetAllEmployees();
        Task<int> CreateEmployee(Employees employees);
        Task<int> UpdateEmployee(Employees employees);
        Task<int> DeleteEmployeeById(Guid empId);
    }
}
