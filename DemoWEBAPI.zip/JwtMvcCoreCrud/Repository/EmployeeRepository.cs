﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DemoCommon.Helper;
using DemoCommon.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace JwtMvcCoreCrud.Repository
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly TestDemoContext _testDemoContext;
        private readonly IHttpContextAccessor _httpContextAccessor;

        /// <summary>
        /// EmployeeRepository
        /// </summary>
        /// <param name="testDemoContext"></param>
        /// <param name="httpContextAccessor"></param>
        public EmployeeRepository(TestDemoContext testDemoContext, IHttpContextAccessor httpContextAccessor)
        {
            _testDemoContext = testDemoContext;
            _httpContextAccessor = httpContextAccessor;
        }

        /// <summary>
        /// CreateEmployee
        /// </summary>
        /// <param name="employees"></param>
        /// <returns></returns>
        public async Task<int> CreateEmployee(Employees employees)
        {
            //AddAuditTrial(employees, true);

            employees.EmpId = Guid.NewGuid();
            await _testDemoContext.Employees.AddAsync(employees).ConfigureAwait(false);

            return await _testDemoContext.SaveChangesAsync().ConfigureAwait(false);
        }

        /// <summary>
        /// AddAuditTrial
        /// </summary>
        /// <param name="employees"></param>
        /// <param name="createOperation"></param>
        private void AddAuditTrial(Employees employees, bool createOperation = false)
        {
            Guid userId = CommonHelper.GetLoggedInUser(_httpContextAccessor).UserId;

            if (createOperation)
            {
                employees.CreateTs = DateTime.UtcNow;
                employees.CreateUser = userId;
            }
            else
            {
                employees.UpdateTs = DateTime.UtcNow;
                employees.UpdateUser = userId;
            }
        }

        /// <summary>
        /// DeleteEmployeeById
        /// </summary>
        /// <param name="empId"></param>
        /// <returns></returns>
        public async Task<int> DeleteEmployeeById(Guid empId)
        {
            var employee = await _testDemoContext.Employees.Where(s => empId.Equals(empId)).ToListAsync().ConfigureAwait(false);

            employee.ForEach(s =>
            {
                s.IsActive = false;
                s.UpdateTs = DateTime.UtcNow;
              //  s.UpdateUser = CommonHelper.GetCurrentUser(_httpContextAccessor);
            });

            _testDemoContext.Employees.UpdateRange(employee);
            return await _testDemoContext.SaveChangesAsync().ConfigureAwait(false);
        }

        /// <summary>
        /// GetAllEmployees
        /// </summary>
        /// <param name="includeDetails"></param>
        /// <returns></returns>

        public async Task<IList<Employees>> GetAllEmployees()
        {
            var employees = await _testDemoContext.Employees
                                      .Where(s => s.IsActive == null || (s.IsActive.HasValue && s.IsActive.Value))
                                      .ToListAsync().ConfigureAwait(false);
            return employees;
        }

        /// <summary>
        /// GetEmployeeById
        /// </summary>
        /// <param name="empId"></param>
        /// <param name="includeDetails"></param>
        /// <returns></returns>
        public async Task<Employees> GetEmployeeById(Guid empId)
        {
            var employees = await _testDemoContext.Employees.
                SingleOrDefaultAsync(s => s.EmpId.Equals(empId) && (s.IsActive == null || (s.IsActive.HasValue && s.IsActive.Value))).ConfigureAwait(false);
            return employees;
        }

        /// <summary>
        /// GetEmployeeByName
        /// </summary>
        /// <param name="name"></param>
        /// <param name="empId"></param>
        /// <returns></returns>

        public async Task<Employees> GetEmployeeByName(Guid empId)
        {
            var employees = await _testDemoContext.Employees.SingleOrDefaultAsync(s => s.EmpId.Equals(empId) && (s.IsActive == null || (s.IsActive.HasValue && s.IsActive.Value))).ConfigureAwait(false);
            return employees;
        }

        /// <summary>
        /// UpdateEmployee 
        /// </summary>
        /// <param name="employees"></param>
        /// <returns></returns>
        public async Task<int> UpdateEmployee(Employees employees)
        {
           // AddAuditTrial(employees);

            _testDemoContext.Employees.Update(employees);

            return await _testDemoContext.SaveChangesAsync().ConfigureAwait(false);
        }
    }
}
