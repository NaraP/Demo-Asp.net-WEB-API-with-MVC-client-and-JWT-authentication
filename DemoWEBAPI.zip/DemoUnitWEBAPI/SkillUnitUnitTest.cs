using DemoCommon.Models;
using DemoWEBAPI.Controllers;
using DemoWEBAPI.Dto;
using DemoWEBAPI.Repository;
using DemoWEBAPI.Services;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Threading.Tasks;
using Xunit;

namespace DemoUnitWEBAPI
{
    public class SkillUnitUnitTest
    {

        SkillsController _controller;
        SkillService _service;

        public SkillUnitUnitTest()
        {
            _service = new SkillService(null);
            //_controller = new SkillsController();
        }
        [Fact]
        public async Task GetAllSkills()
        {
            // Arrange
            var mockRepo = new Mock<ISkillRepository>();
            //mockRepo.Setup(repo => repo.ListAsync())
            //    .ReturnsAsync(GetTestSessions());
            var controller = new SkillsController(mockRepo.Object);

            // Act
            var result = await controller.Index();

            // Assert
           // var viewResult = Assert.IsType<ViewResult>(result);
            //var model = Assert.IsAssignableFrom<IEnumerable<Skill>>(
              //  viewResult.ViewData.Model);
            //Assert.Equal(2, model.Count());
        }

        [Fact]
        public async void CreateNesSkill()
        {
            var company = new SkillModel { SkillName = ".Net Core",SkillId=Guid.NewGuid() };
            var mockRepo = new Mock<SkillService>();
            mockRepo.Setup(x => x.CreateSkill(company));

            //var objectCRUD = new SkillService(mockRepo.Object);
           //  var data = objectCRUD.CreateSkill(company);
           // Assert.AreEqual(data, true);
        }

    }
}
