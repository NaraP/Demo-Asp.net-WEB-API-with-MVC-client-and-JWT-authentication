﻿using DemoCommon.Models;
using DemoWEBAPI.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DemoWEBAPI.Mapper
{
    public static class EmployeeMapper
    {
        public static Employees MapEmpmodelToEmployee(EmployeeModel employeeModel)
        {
            return new Employees
            {
                EmpId = Guid.NewGuid(),
                Name = employeeModel.Name,
                Address = employeeModel.Address,
                Gender = employeeModel.Gender,
                Company = employeeModel.Company,
                Designation = employeeModel.Designation
            };
        }

        public static EmployeeModel MapEmpsToEmpDto(this Employees employeeModel)
        {
            return new EmployeeModel
            {
                EmpId = employeeModel.EmpId,
                Name = employeeModel.Name,
                Address = employeeModel.Address,
                Gender = employeeModel.Gender,
                Company = employeeModel.Company,
                Designation = employeeModel.Designation
            };
        }

        public static Employees MapempsDtosToUpdateEmps(this EmployeeModel employeeModel, Employees employees)
        {
            employees.Name = employeeModel.Name;
            employees.Address = employeeModel.Address;
            employees.Gender = employeeModel.Gender;
            employees.Company = employeeModel.Company;
            employees.Designation = employeeModel.Designation;

            return employees;
        }

        public static IList<EmployeeModel> MapEmpToEmpListDto(this IList<Employees> employees)
        {
            var empList = new List<EmployeeModel>();

            foreach (var emps in employees)
            {
                var empsData = MapEmpsToEmpDto(emps);
                empList.Add(empsData);
            }

            return empList;
        }
    }
}
