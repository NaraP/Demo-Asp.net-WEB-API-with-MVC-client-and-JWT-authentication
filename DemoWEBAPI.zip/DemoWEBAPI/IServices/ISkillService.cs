﻿using DemoCommon.Helper;
using DemoWEBAPI.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DemoWEBAPI.IServices
{
    public interface ISkillService
    {
        //Task<ResponseMessage> GetAllSkills(bool includeDetails);
        //Task CreateSkill(SkillModel skillModel);
        //Task UpdateSkill(SkillModel skillModel);
        //Task DeleteSkillById(Guid skillIds);
        //Task<SkillModel> GetSkillsById(string id);

        Task<ResponseMessage> GetAllSkills();
        Task<ResponseMessage> CreateSkill(SkillModel skillModel);
        Task<ResponseMessage> UpdateSkill(SkillModel skillModel);
        Task<ResponseMessage> DeleteSkillById(Guid skillIds);

        Task<ResponseMessage> GetSkillById(Guid skillId);
    }
}
