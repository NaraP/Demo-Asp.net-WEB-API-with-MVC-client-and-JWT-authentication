﻿using DemoCommon.Helper;
using DemoWEBAPI.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DemoWEBAPI.IServices
{
   public interface IEmployeeService
    {
        Task<ResponseMessage> GetAllEmployees(bool includeDetails);
        Task<ResponseMessage> CreateEmployeel(EmployeeModel employeeModel);
        Task<ResponseMessage> UpdateEmployee(EmployeeModel employeeModel);
        Task<ResponseMessage> DeleteEmployeeById(Guid empIds);
    }
}
