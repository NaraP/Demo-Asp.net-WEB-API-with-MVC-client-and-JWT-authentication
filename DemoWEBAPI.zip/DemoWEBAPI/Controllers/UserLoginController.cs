﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DemoCommon.Dto;
using DemoCommon.IServices;
using DemoWEBAPI.Dto;
using DemoWEBAPI.Helper;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace DemoWEBAPI.Controllers
{
   // [Route("api/[controller]")]
   [ApiController]
    public class UserLoginController : ControllerBase
    {
        private readonly IUserAuthService _usersService;
        private readonly ITokenStoreService _tokenStoreService;
        private readonly IAntiForgeryCookieService _antiforgery;
        private readonly ILogger _loginLogger;
        private readonly IHostingEnvironment _hostingEnvironment;   
        private readonly IConfiguration _configuration;

        public UserLoginController(IUserAuthService usersService,
                         ITokenStoreService tokenStoreService, ILogger<UserLoginController> logger, IHostingEnvironment hostingEnvironment,
                         IAntiForgeryCookieService antiforgery,
                        IConfiguration configuration)
        {
            _usersService = usersService;
           // _usersService.CheckArgumentIsNull(nameof(usersService));

            _tokenStoreService = tokenStoreService;
            _antiforgery = antiforgery;
            _loginLogger = logger;
            _hostingEnvironment = hostingEnvironment;
            _configuration = configuration;
        }

        [HttpPost]
        [ProducesResponseType(200, Type = typeof(LoginModel))]
        [ProducesResponseType(404)]
        [ProducesResponseType(400)]
        //[Authorize(Policy = AbbRelCareRoles.SuperUser)]
        [Route("api/UserLogin/Login")]

        public async Task<ActionResult> Login([FromBody]  LoginModel loginModel)
        {
            UserDto userDto = new UserDto
            {
                UserName = loginModel.UserName,
                Password = loginModel.Password
            };

            //userDto.CheckArgumentIsNull(nameof(userDto));

            var user = default(UserDto);

            user = await _usersService.FindUserAsync(userDto);

            if (user == null)
            {
                return StatusCode(401, new ResponseMsg { StatusCode = 401, ErrorMessage = "Invalid Email or Password" });
            }

            var tokenDto = await _tokenStoreService.CreateJwtTokens(user, refreshTokenSource: null);

            _antiforgery.RegenerateAntiForgeryCookies(tokenDto.Claims);

            return Ok(new { access_token = tokenDto.AccessToken});

            //return Ok(new { access_token = tokenDto.AccessToken, refresh_token = tokenDto.RefreshToken, tokenDto.Serialnumber, userId = tokenDto.UserId, userfullName = tokenDto.UserFullName });

        }
    }
}