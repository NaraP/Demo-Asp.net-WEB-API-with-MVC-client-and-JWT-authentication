﻿namespace DemoWEBAPI.Swagger
{
    /// <summary>
    /// SwaggerSettings
    /// </summary>
    public class SwaggerSettings
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public string TermsOfService { get; set; }
        public string Name { get; set; }
    }
}
