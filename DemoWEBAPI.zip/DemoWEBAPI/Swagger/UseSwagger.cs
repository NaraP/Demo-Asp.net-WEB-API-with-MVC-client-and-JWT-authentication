﻿using Microsoft.AspNetCore.Builder;

namespace DemoWEBAPI.Swagger
{
    public static class UseSwagger
    {
        public static void UseSwaggerMiddleWare(this IApplicationBuilder app)
        {
            app.UseSwagger();

            app.UseSwaggerUI(c =>
            {
                const string Url = "/swagger/v1/swagger.json";
                c.SwaggerEndpoint(Url, "Demo project");
                c.RoutePrefix = string.Empty;
            });
        }
    }
}
