﻿using DemoCommon.Helper;
using DemoCommon.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DemoWEBAPI.Repository
{
    public class SkillRepository : ISkillRepository
    {
        private readonly TestDemoContext _testDemoContext;
        private readonly IHttpContextAccessor _httpContextAccessor;

        #region SkillRepository Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="rcs_db_devContext"></param>
        /// <param name="httpContextAccessor"></param>
        public SkillRepository(TestDemoContext testDemoContext, IHttpContextAccessor httpContextAccessor)
        {
            _testDemoContext = testDemoContext;
            _httpContextAccessor = httpContextAccessor;
        }

        #endregion

        #region CreateSkill

        /// <summary>
        /// CreateSkill function is used to add new skill into the database
        /// </summary>
        /// <param name="skill"></param>
        /// <returns></returns>
        public async Task<int> CreateSkill(Skill skill)
        {
            //AddAuditTrial(skill, true);

            await _testDemoContext.Skill.AddAsync(skill).ConfigureAwait(false);

            return await _testDemoContext.SaveChangesAsync().ConfigureAwait(false);
        }

        #endregion

        #region DeleteSkillById

        /// <summary>
        /// DeleteSkillById function deletes the skill from the database
        /// </summary>
        /// <param name="skillIds"></param>
        /// <returns></returns>
        public async Task<int> DeleteSkillById(Guid skillIds)
        {

            var skill = await _testDemoContext.Skill.Where(s => skillIds.Equals(skillIds)).ToListAsync().ConfigureAwait(false);

            skill.ForEach(s =>
            {
                s.IsActive = false;
                s.UpdateTs = DateTime.UtcNow;
                s.UpdateUser = CommonHelper.GetCurrentUser(_httpContextAccessor);
            });

            _testDemoContext.Skill.UpdateRange(skill);
            return await _testDemoContext.SaveChangesAsync().ConfigureAwait(false);
        }

        #endregion

        #region GetAllSkills

        /// <summary>
        /// GetAllSkills function fetches the complete list of all the created skills from the database
        /// </summary>
        /// <param name="includeDetails"></param>
        /// <returns></returns>
        public async Task<IList<Skill>> GetAllSkills(bool includeDetails)
        {
            var skills = await _testDemoContext.Skill
                               .Where(s => s.IsActive == null || (s.IsActive.HasValue && s.IsActive.Value))
                               .ToListAsync().ConfigureAwait(false);
            return skills;
        }

        #endregion

        #region GetSkillById

        /// <summary>
        /// GetSkillById function fetches the details of the specific skill from the database
        /// </summary>
        /// <param name="id"></param>
        /// <param name="includeDetails"></param>
        /// <returns></returns>
        public async Task<Skill> GetSkillById(Guid id)
        {
            var skill = await _testDemoContext.Skill.SingleOrDefaultAsync(s => s.SkillId.Equals(id) && (s.IsActive == null || (s.IsActive.HasValue && s.IsActive.Value))).ConfigureAwait(false);
            return skill;
        }

        #endregion

        #region GetSkillByName

        /// <summary>
        /// GetSkillById function fetches the details of the specific skill from the database
        /// </summary>
        /// <param name="name"></param>
        /// <param name="skillId"></param>
        /// <returns></returns>
        public async Task<Skill> GetSkillByName(string name, Guid skillId)
        {
            if (skillId == Guid.Empty)
            {
                var skill = await _testDemoContext.Skill.SingleOrDefaultAsync(s => s.SkillName.Trim().ToLower().Equals(name.Trim().ToLower()) && (s.IsActive == null || (s.IsActive.HasValue && s.IsActive.Value))).ConfigureAwait(false);
                return skill;
            }
            else
            {
                var skill = await _testDemoContext.Skill.
                                           SingleOrDefaultAsync(s => (s.SkillName.Trim().ToLower().Equals(name.Trim().ToLower()) && s.SkillId != skillId) && (s.IsActive == null || (s.IsActive.HasValue && s.IsActive.Value))).ConfigureAwait(false);
                return skill;
            }
        }

        #endregion

        #region UpdateSkill

        /// <summary>
        /// UpdateSkill function updates the already existing skill details into the database
        /// </summary>
        /// <param name="skill"></param>
        /// <returns></returns>
        public async Task<int> UpdateSkill(Skill skill)
        {
            //AddAuditTrial(skill);

            _testDemoContext.Skill.Update(skill);

            return await _testDemoContext.SaveChangesAsync().ConfigureAwait(false);
        }

        #endregion

        #region AddAuditTrial

        /// <summary>
        /// AddAuditTrial
        /// </summary>
        /// <param name="skill"></param>
        /// <param name="createOperation"></param>
        private void AddAuditTrial(Skill skill, bool createOperation = false)
        {
            //Guid userId = CommonHelper.GetLoggedInUser(_httpContextAccessor).UserId;

            //if (createOperation)
            //{
            //    skill.CreateTs = DateTime.UtcNow;
            //    skill.CreateUser = userId;
            //}
            //else
            //{
            //    skill.UpdateTs = DateTime.UtcNow;
            //    skill.UpdateUser = userId;
            //}
        }

        #endregion
    }
}
