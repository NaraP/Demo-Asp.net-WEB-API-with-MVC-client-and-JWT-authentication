﻿using DemoCommon.Models;
using DemoWEBAPI.Controllers;
using DemoWEBAPI.Repository;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace DemoUnitWEBAPI
{
  public  class EmployeeTestController
    {

        EmployeesController _controller;
        IEmployeesRepository _service;

        public EmployeeTestController()
        {
            _controller = new EmployeesController(_service);
        }

        [Fact]
        public void GetDataReturnsOkResult()
        {
            var mock = new Mock<IEmployeesRepository>();
            mock.Setup(p => p.GetEmployee("f55c9ef3-c8b8-4e8f-846a-d96eacb2a987"));
            EmployeesController emp = new EmployeesController(mock.Object);
            var result = emp.Get();
            Assert.Equal("ABC", result.Result.ToString());
        }

        [Fact]
        public void Get_ReturnsAllItems()
        {
            var mock = new Mock<IEmployeesRepository>();
            mock.Setup(p => p.GetEmployees());
            EmployeesController emp = new EmployeesController(mock.Object);
            var result = emp.Get();
            Assert.Equal("ABC", result.Result.ToString());
        }
        [Fact]
        public void Get_ReturnsDelete()
        {
            var mock = new Mock<IEmployeesRepository>();
            mock.Setup(p => p.Delete("f55c9ef3-c8b8-4e8f-846a-d96eacb2a987"));
            EmployeesController home = new EmployeesController(mock.Object);
            var result = home.DeleteConfirmedAsync("f55c9ef3-c8b8-4e8f-846a-d96eacb2a987");
            Assert.Equal("ABC",result.ToString());
        }

        [Fact]
        public void Get_ReturnsDetails()
        {
            var mock = new Mock<IEmployeesRepository>();
            mock.Setup(p => p.GetEmployee("f55c9ef3-c8b8-4e8f-846a-d96eacb2a987"));
            EmployeesController home = new EmployeesController(mock.Object);
            var result = home.Details("f55c9ef3-c8b8-4e8f-846a-d96eacb2a987");
            Assert.Equal("ABC", result.ToString());
        }

        [Fact]
        public void Get_ReturnsCreate()
        {
            Employees employees = new Employees();
            employees.EmpId = Guid.NewGuid();
            employees.Name = "ABB";
            employees.Gender = "M";
            employees.Designation = "OT";

            var mock = new Mock<IEmployeesRepository>();

            mock.Setup(p => p.Add(employees));
            EmployeesController home = new EmployeesController(mock.Object);
            var result = home.CreateAsync(employees);
            Assert.Equal("ABC", result.ToString());
        }

        [Fact]
        public void Get_ReturnsUpdate()
        {
            Employees employees = new Employees();
            employees.EmpId = Guid.NewGuid();
            employees.Name = "ABC";
            employees.Gender = "M";
            employees.Designation = "OT";

            var mock = new Mock<IEmployeesRepository>();

            mock.Setup(p => p.Add(employees));
            EmployeesController home = new EmployeesController(mock.Object);
            var result = home.EditAsync(employees);
            Assert.Equal("ABC", result.ToString());
        }

    }
}
