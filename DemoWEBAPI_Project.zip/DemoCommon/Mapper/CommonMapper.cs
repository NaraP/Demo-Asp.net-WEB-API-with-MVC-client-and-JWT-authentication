﻿using DemoCommon.Dto;
using DemoCommon.Extensions;
using DemoCommon.Helper;
using DemoCommon.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DemoCommon.Mapper
{
   public static class CommonMapper
    {
        public static UserToken MapUserTokenDTOToUserToken(UserTokenDto userTokenDto)
        {
            UserToken userToken = new UserToken
            {
                UserTokenId = Guid.NewGuid(),
                AccessTokenHash = userTokenDto.AccessTokenHash,
                AccessTokenExpiresTs = userTokenDto.AccessTokenExpiresDateTime,
                RefreshTokenIdHash = userTokenDto.RefreshTokenIdHash,
                RefreshTokenIdHashSource = userTokenDto.RefreshTokenIdHashSource,
                RefreshTokenExpiresTs = userTokenDto.RefreshTokenExpiresDateTime,
                CreateUser = userTokenDto.Id,
                UserId = userTokenDto.UserId,
                CreateTs = DateTime.Now.ToUniversalTime(),
                UpdateTs = DateTime.Now.ToUniversalTime(),
                IsActive = true,
                UpdateUser = userTokenDto.UserId
            };
            return userToken;
        }

        public static UserDto UserToUserDto(this User user, bool includeDetails = true)
        {
            user.CheckArgumentIsNull(nameof(user));

            var userDto = new UserDto();

            userDto.UserId = Guid.Empty.Equals(user.UserId) ? Guid.NewGuid() : user.UserId;
            userDto.UserName = user.UserName;
            userDto.FirstName = user.FirstName;
            userDto.SurName = user.SurName;
            userDto.PerfRating = user.PerfRating;
            userDto.Employer = user.Employer;
            userDto.JobPosition = user.JobPosition;
            userDto.EmailId = user.EmailId;
            

            if (user.HourlyRate != null)
            {
                userDto.HourlyRate = user.HourlyRate.Value;
            }
            else
            {
                userDto.HourlyRate = 0;
            }
            userDto.EnableSkill = user.EnableSkill;
            userDto.SerialNumber = user.SerialNumber;
            userDto.FullName = user.FirstName + " " + user.SurName;

            if (includeDetails)
            {
                //Roles            
                if (user.UserRole != null && user.UserRole.Count > 0)
                {
                    userDto.UserRolesDtoList = UserRolesListToUserRolesDtoList(user.UserRole, user.UserId);

                    foreach (UserRole userRole in user.UserRole)
                    {
                        if (userRole.Role.IsSystemRole)
                        {
                            userDto.IsSystemRole = true;
                            break;
                        }
                    }
                }

                //Securables Priviledges
                userDto.UserPriviledges = new UserPriviledgesDto();
                foreach (UserRole role in user.UserRole)
                {
                    foreach (RolePrivilegeSecurable rolePrivilegeSecurable in role.Role.RolePrivilegeSecurable)
                    {
                        userDto.UserPriviledges.Priviledges.Add(rolePrivilegeSecurable.Securable.SecurableDesc + rolePrivilegeSecurable.Privilege.PrivilegeName);

                        if (rolePrivilegeSecurable.Privilege.PrivilegeName.Equals(PermissionUserRoles.Edit))
                        {
                            userDto.UserPriviledges.Priviledges.Add(rolePrivilegeSecurable.Securable.SecurableDesc + PermissionUserRoles.View);
                        }
                    }
                }
            }

            return userDto;
        }

        /// <summary>
        /// List level - Mapping User Roles list to User Roles dto list
        /// </summary>
        /// <param name="usersRolesList"></param>
        /// <param name="userId"></param>
        /// <returns>User Roles dto list object</returns>
        public static ICollection<UserRolesCommonDto> UserRolesListToUserRolesDtoList(ICollection<UserRole> usersRolesList, Guid userId)
        {
            var userRolesDtoList = new List<UserRolesCommonDto>();

            foreach (var userRole in usersRolesList)
            {
                if (userRole.IsActive.Equals(true))//Adding active roles only
                {
                    UserRolesCommonDto userRoleDto = UserRoleToUserRoleDto(userRole, userId);
                    userRolesDtoList.Add(userRoleDto);
                }
            }
            return userRolesDtoList;
        }

        public static UserRolesCommonDto UserRoleToUserRoleDto(UserRole userRole, Guid userId)
        {
            return new UserRolesCommonDto
            {
                //UserId = userId != null ? userRole.UserId : userId ,   SonarQube Non compliance
                UserId = userRole.UserId,  //SonarQube compliance
                RoleId = userRole.RoleId,
                RoleDto = new RolesCommonDto { Roleid = userRole.RoleId, Rolename = userRole.Role.RoleName },
                IsSystemRole = userRole.Role.IsSystemRole
            };
        }
    }
}
