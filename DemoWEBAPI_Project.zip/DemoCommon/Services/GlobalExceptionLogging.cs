﻿using DemoCommon.IServices;
using DemoCommon.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DemoCommon.Services
{
    /// <summary>
    /// GlobalExceptionLogging
    /// </summary>
    public class GlobalExceptionLogging : IGlobalExceptionLogging
    {
        private readonly TestDemoContext _testDemoContext;

        /// <summary>
        /// GlobalExceptionLogging
        /// </summary>
        /// <param name="abbRelCareContext"></param>
        /// <param name="logger"></param>
        public GlobalExceptionLogging(TestDemoContext testDemoContext)
        {
            _testDemoContext = testDemoContext;
        }

        /// <summary>
        /// SaveGlobalExceptionLogging method is used for the global exception saved into the database
        /// </summary>
        /// <param name="exceptionLog"></param>
        public void SaveGlobalExceptionLogging(ExceptionLog exceptionLog)
        {
            _testDemoContext.ExceptionLog.Add(exceptionLog);

            _testDemoContext.SaveChanges();
        }
    }
}
