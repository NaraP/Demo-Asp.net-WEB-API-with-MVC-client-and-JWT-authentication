﻿using DemoCommon.Dto;
using DemoCommon.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DemoCommon.IServices
{
    public interface IUserAuthService
    {
        Task AddUserTokenAsync(UserDto user, string refreshToken, string accessToken, string refreshTokenSource);
        Task<UserDto> FindUserAsync(UserDto userDto);

        Task UpdateUserLastActivityDateAsync(Guid userId);
        Task DeleteTokensWithSameRefreshTokenSourceAsync(string refreshTokenIdHashSource);
        Task<UserDto> FindUserAsyncById(Guid userId);
        //Task ResetPassword(UserDto resetUserPassword);
        User GetSlat(string guid);
    }
}
