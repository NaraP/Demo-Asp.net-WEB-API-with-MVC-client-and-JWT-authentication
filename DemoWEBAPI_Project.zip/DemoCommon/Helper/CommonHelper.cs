﻿using DemoCommon.Dto;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Text;

namespace DemoCommon.Helper
{
   public static class CommonHelper
    {
        /// <summary>
        /// GetCurrentUser
        /// </summary>
        /// <param name="httpContextAccessor"></param>
        /// <returns></returns>
        public static Guid GetCurrentUser(IHttpContextAccessor httpContextAccessor)
        {
            Guid userId = Guid.Empty;

            if (httpContextAccessor.HttpContext.User != null && httpContextAccessor.HttpContext.User.HasClaim(c => c.Type == ClaimTypes.UserData))
            {
                userId = Guid.Parse(httpContextAccessor.HttpContext.User.FindFirst(c => c.Type == ClaimTypes.UserData).Value);
            }
            else
            {
               throw new UnauthorizedAccessException();
            }

            return userId;
        }


        /// <summary>
        /// GetLoggedInUser
        /// </summary>
        /// <param name="httpContextAccessor"></param>
        /// <returns></returns>
        public static LoggedInUserDto GetLoggedInUser(IHttpContextAccessor httpContextAccessor)
        {

            LoggedInUserDto loggedInUserDto = null;

            if (httpContextAccessor.HttpContext.User?.Identity != null && httpContextAccessor.HttpContext.User.Identity.IsAuthenticated)
            {
                loggedInUserDto = new LoggedInUserDto();
                loggedInUserDto.UserId = Guid.Parse(httpContextAccessor.HttpContext.User.FindFirst(c => c.Type == ClaimTypes.UserData).Value);
                loggedInUserDto.UserName = (httpContextAccessor.HttpContext.User.FindFirst(c => c.Type == ClaimTypes.Name).Value);
                loggedInUserDto.Email = (httpContextAccessor.HttpContext.User.FindFirst(c => c.Type == ClaimTypes.Email).Value);

                var allClaims = httpContextAccessor.HttpContext.User.Claims;

                foreach (Claim claim in allClaims)
                {
                    if (claim.Type == ClaimTypes.Role)
                    {
                        loggedInUserDto.Roles.Add(claim.Value);
                    }
                    else if (claim.Type == "IsSystemRole")
                    {
                        loggedInUserDto.IsSystemRole = Convert.ToBoolean(claim.Value);
                    }
                    else if (!loggedInUserDto.ClaimsList.Contains(claim.Type))
                    {
                        loggedInUserDto.Priviledges.Add(claim.Value);
                    }
                    else
                    {
                        loggedInUserDto.Claims.Add(claim.Value);
                    }
                }
            }
            else
                throw new UnauthorizedAccessException();

            return loggedInUserDto;
        }
    }
}
