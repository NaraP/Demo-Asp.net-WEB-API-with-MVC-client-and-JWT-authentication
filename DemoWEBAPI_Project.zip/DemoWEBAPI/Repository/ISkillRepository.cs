﻿using DemoCommon.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DemoWEBAPI.Repository
{
    public interface ISkillRepository
    {
        Task<Skill> GetSkillById(Guid id);
        Task<Skill> GetSkillByName(string name, Guid skillId);
        Task<IList<Skill>> GetAllSkills(bool includeDetails);
        Task<int> CreateSkill(Skill skill);
        Task<int> UpdateSkill(Skill skill);
        Task<int> DeleteSkillById(Guid skillIds);
    }
}
