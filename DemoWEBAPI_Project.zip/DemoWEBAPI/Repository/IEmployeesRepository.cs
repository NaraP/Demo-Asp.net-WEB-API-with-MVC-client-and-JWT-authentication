﻿using DemoCommon.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DemoWEBAPI.Repository
{
    public interface IEmployeesRepository
    {
        Task Add(Employees employee);
        Task Update(Employees employee);
        Task Delete(string id);
        Task<Employees> GetEmployee(string id);
        Task<IEnumerable<Employees>> GetEmployees();
    }
}
