﻿using DemoCommon.Dto;
using DemoCommon.IServices;
using DemoCommon.Services;
using DemoWEBAPI.IServices;
using DemoWEBAPI.Repository;
using DemoWEBAPI.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DemoWEBAPI
{
    public static class RegisterServices
    {
        /// <summary>
        /// RegisterChainOfConfigServices this is used for the registrations of the all services and repositories
        /// </summary>
        /// <param name="services"></param>
        /// <param name="configuration"></param>
        public static void RegisterConfigServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddScoped<ISkillRepository, SkillRepository>();
            services.AddScoped<ISkillService, SkillService>();

           // services.AddScoped<IEmployeeRepository, EmployeeRepository>();
            services.AddScoped<IEmployeeService, EmployeeService>();

            #region --JWT--
            services.Configure<BearerTokensOptions>(options => configuration.GetSection("BearerTokens").Bind(options));
            services.AddScoped<IUserAuthService, UserAuthService>();
            services.AddSingleton<ISecurityService, SecurityService>();
            services.AddScoped<ITokenStoreService, TokenStoreService>();
            services.AddScoped<ITokenValidatorService, TokenValidatorService>();
            services.AddScoped<IGlobalExceptionLogging, GlobalExceptionLogging>();
            services.AddScoped<IAntiForgeryCookieService, AntiForgeryCookieService>();
            #endregion
        }
    }
}
