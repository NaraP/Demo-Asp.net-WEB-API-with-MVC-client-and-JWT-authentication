﻿using DemoCommon.Helper;
using DemoWEBAPI.Dto;
using DemoWEBAPI.IServices;
using DemoWEBAPI.Mapper;
using DemoWEBAPI.Repository;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace DemoWEBAPI.Services
{
    public class SkillService : ISkillService
    {
        private readonly ISkillRepository _skillRepository;
        private readonly ILogger<SkillService> _logger;
        readonly ResponseMessage responseMessage = new ResponseMessage();

        /// <summary>
        /// SkillService
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="skillRepository"></param>
        /// <param name="localizer"></param>
        public SkillService(ILogger<SkillService> logger, ISkillRepository skillRepository)
        {
            _skillRepository = skillRepository;
            _logger = logger;
            //CheckArguments();
        }
        public SkillService(ISkillRepository skillRepository)
        {
        }



        /// <summary>
        /// CreateSkill this method is used for the create the skills
        /// </summary>
        /// <param name="skillDto"></param>
        // <returns></returns>
        public async Task<ResponseMessage> CreateSkill(SkillModel skillModel)
        {
            _logger.LogInformation($"Service-CreateSkill-Executing started at {DateTime.UtcNow}");

            var returnSkillDto = default(SkillModel);
            responseMessage.StatusCode = Convert.ToInt32(HttpStatusCode.InternalServerError);

            //Check if Skill exists or not
            var skillResult = await _skillRepository.GetSkillByName(skillModel.SkillName, skillModel.SkillId).ConfigureAwait(false);

            var skill = skillModel?.MapSkillDtoToSkill();

            if (skillResult == null)
            {
                var result = await _skillRepository.CreateSkill(skill).ConfigureAwait(false);

                if (result != 0)
                {
                    returnSkillDto = skill.MapSkillToSkillDto();
                    responseMessage.StatusCode = Convert.ToInt32(HttpStatusCode.Created);
                    responseMessage.StatusDescription = Convert.ToString(HttpStatusCode.Continue);
                    responseMessage.returnObj = skill.SkillName;
                }
                else
                {
                    responseMessage.StatusCode = Convert.ToInt32(HttpStatusCode.BadRequest);
                    responseMessage.StatusDescription = "Skill creation failed";
                    responseMessage.ErrorMessage = $"Skill Name {skillModel.SkillName} creation failed";
                }
            }
            else
            {
                responseMessage.StatusCode = Convert.ToInt32(HttpStatusCode.Conflict);
                responseMessage.StatusDescription = "Skill already exists";
                //responseMessage.ErrorMessage = $"{_localizer["SkillName"].Value} {skillDto.SkillName} {_localizer["AlreadyExists"].Value}";
                responseMessage.ErrorMessage = $"Skill Name {skillModel.SkillName} already exists";
            }

            _logger.LogInformation($"Service-CreateSkill-Executing completed at {DateTime.UtcNow}");

            return responseMessage;
        }

        /// <summary>
        /// DeleteSkillById
        /// </summary>
        /// <param name="skillIds"></param>
        /// <returns></returns>
        public async Task<ResponseMessage> DeleteSkillById(Guid skillIds)
        {
            _logger.LogInformation($"Service-DeleteSkillById-Executing started at {DateTime.UtcNow}");

            string skillNames = string.Empty;

            //check sillId's exist or not
         
                var skill = await _skillRepository.GetSkillById(skillIds).ConfigureAwait(false);

                var result = await _skillRepository.DeleteSkillById(skillIds).ConfigureAwait(false);

                if (result != 0)
                {
                    responseMessage.StatusCode = Convert.ToInt32(HttpStatusCode.OK);
                    responseMessage.StatusDescription = "skills deleted sucesfully";
                }
                else
                {
                    responseMessage.StatusCode = Convert.ToInt32(HttpStatusCode.BadRequest);
                    responseMessage.StatusDescription = "skills not found";
                }

            _logger.LogInformation($"Service-DeleteSkillById-Executing completed at {DateTime.UtcNow}");

            return responseMessage;
        }

        public async Task<ResponseMessage> GetSkillById(Guid skillId)
        {
            _logger.LogInformation($"Service-GetSkillById-Executing started at {DateTime.UtcNow}");

            string skillNames = string.Empty;
            var returnSkillDto = default(SkillModel);

            //check sillId's exist or not

            var skill = await _skillRepository.GetSkillById(skillId).ConfigureAwait(false);

            if (skill != null)
            {
                returnSkillDto = skill.MapSkillToSkillDto();

                responseMessage.StatusCode = Convert.ToInt32(HttpStatusCode.OK);
                responseMessage.returnObj = returnSkillDto;

            }
            else
            {
                responseMessage.StatusCode = Convert.ToInt32(HttpStatusCode.BadRequest);
                responseMessage.StatusDescription = "skills not found";
            }

            _logger.LogInformation($"Service-DeleteSkillById-Executing completed at {DateTime.UtcNow}");

            return responseMessage;
        }

        /// <summary>
        /// UpdateSkill
        /// </summary>
        /// <param name="skillDto"></param>
        /// <returns></returns>
        public async Task<ResponseMessage> UpdateSkill(SkillModel skillModel)
        {
            _logger.LogInformation($"Service-UpdateSkill-Executing started at {DateTime.UtcNow}");

            var skillResult = await _skillRepository.GetSkillByName(skillModel.SkillName, skillModel.SkillId).ConfigureAwait(false);

            if (skillResult != null)
            {
                responseMessage.StatusCode = Convert.ToInt32(HttpStatusCode.Conflict);
                responseMessage.StatusDescription = "Skill already exists";
                responseMessage.ErrorMessage = string.Format("Skill Name {0} already exists", skillModel.SkillName);

                return responseMessage;
            }

            var skill = await _skillRepository.GetSkillById(skillModel.SkillId).ConfigureAwait(false);

            if (skill != null)
            {
                skill = skillModel.MapSkillDtosToUpdateSkill(skill);

                var result = await _skillRepository.UpdateSkill(skill);

                if (result != 0)
                {
                    responseMessage.StatusCode = Convert.ToInt32(HttpStatusCode.OK);
                    responseMessage.returnObj = skill.SkillName;//skill?.MapSkillToSkillDto();
                }
                else
                {
                    _logger.LogInformation("No Skill found.");
                    responseMessage.StatusCode = Convert.ToInt32(HttpStatusCode.NotFound);
                    responseMessage.StatusDescription = "No Skill found.";
                    responseMessage.ErrorMessage = $"skill name {skillModel.SkillName} not found";
                }
            }
            else
            {
                _logger.LogInformation("No Skill found.");
                responseMessage.StatusCode = Convert.ToInt32(HttpStatusCode.NotFound);
                responseMessage.StatusDescription = "No Skill found.";
                //responseMessage.ErrorMessage = $"{_localizer["SkillName"].Value} {skillDto.SkillName} {_localizer["NotFound"].Value}";
                responseMessage.ErrorMessage = $"skill name {skillModel.SkillName} not found.";
            }

            _logger.LogInformation($"Service-UpdateSkill-Executing completed at {DateTime.UtcNow}");
            return responseMessage;
        }


        /// <summary>
        /// GetAllSkills
        /// </summary>
        /// <param name="includeDetails"></param>
        /// <returns></returns>
        public async Task<ResponseMessage> GetAllSkills()
        {
            _logger.LogInformation($"Service-GetAllSkills-Executing started at {DateTime.UtcNow}");

            var skill = await _skillRepository.GetAllSkills(true).ConfigureAwait(false);

            if (skill.Any())
            {
                responseMessage.StatusCode = Convert.ToInt32(HttpStatusCode.OK);
                responseMessage.returnObj = SkillMapper.MapSkillToSkillDto(skill);
            }
            else
            {
                _logger.LogInformation("No skills found");
                responseMessage.StatusCode = Convert.ToInt32(HttpStatusCode.NotFound);
            }

            _logger.LogInformation($"Service-GetAllSkills-Executing completed at {DateTime.UtcNow}");

            return responseMessage;
        }


    }
}
