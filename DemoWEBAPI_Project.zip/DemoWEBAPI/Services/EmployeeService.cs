﻿using DemoCommon.Helper;
using DemoWEBAPI.Dto;
using DemoWEBAPI.IServices;
using DemoWEBAPI.Mapper;
using DemoWEBAPI.Repository;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace DemoWEBAPI.Services
{
    public class EmployeeService : IEmployeeService
    {
        //private readonly IEmployeeRepository _employeeRepository;
        //private readonly ILogger<EmployeeService> _logger;
        //readonly ResponseMessage responseMessage = new ResponseMessage();

        ///// <summary>
        ///// EmployeeService
        ///// </summary>
        ///// <param name="logger"></param>
        ///// <param name="employeeRepository"></param>
        //public EmployeeService(ILogger<EmployeeService> logger, IEmployeeRepository employeeRepository)
        //{
        //    _employeeRepository = employeeRepository;
        //    _logger = logger;
        //    //CheckArguments();
        //}

        ///// <summary>
        ///// CreateEmployeel
        ///// </summary>
        ///// <param name="employeeModel"></param>
        ///// <returns></returns>
        //public async Task<ResponseMessage> CreateEmployeel(EmployeeModel employeeModel)
        //{
        //    _logger.LogInformation($"Service-CreateEmployeel-Executing started at {DateTime.UtcNow}");

        //    responseMessage.StatusCode = Convert.ToInt32(HttpStatusCode.InternalServerError);

        //    var empExist = await _employeeRepository.GetEmployeeByName(employeeModel.Name, employeeModel.EmpId).ConfigureAwait(false);

        //    var newEmployee = EmployeeMapper.MapEmpmodelToEmployee(employeeModel);

        //    if (empExist == null)
        //    {
        //        var result = await _employeeRepository.CreateEmployee(newEmployee).ConfigureAwait(false);

        //        if (result != 0)
        //        {
        //            responseMessage.StatusCode = Convert.ToInt32(HttpStatusCode.Created);
        //            responseMessage.StatusDescription = Convert.ToString(HttpStatusCode.Continue);
        //            responseMessage.returnObj = newEmployee.Name;
        //        }
        //        else
        //        {
        //            responseMessage.StatusCode = Convert.ToInt32(HttpStatusCode.BadRequest);
        //            responseMessage.StatusDescription = "Employee creation failed";
        //            responseMessage.ErrorMessage = $"Employee name {employeeModel.Name} creation failed";
        //        }
        //    }
        //    else
        //    {
        //        responseMessage.StatusCode = Convert.ToInt32(HttpStatusCode.Conflict);
        //        responseMessage.StatusDescription = "SkiEmployee name already exists";
        //        responseMessage.ErrorMessage = $"Employee name {employeeModel.Name} already exists";
        //    }

        //    _logger.LogInformation($"Service-CreateEmployeel-Executing completed at {DateTime.UtcNow}");

        //    return responseMessage;
        //}

        ///// <summary>
        ///// DeleteEmployeeById
        ///// </summary>
        ///// <param name="EmpIds"></param>
        ///// <returns></returns>
        //public async Task<ResponseMessage> DeleteEmployeeById(Guid EmpIds)
        //{
        //    _logger.LogInformation($"Service-DeleteEmployeeById-Executing started at {DateTime.UtcNow}");

        //    var employees = await _employeeRepository.GetEmployeeById(EmpIds).ConfigureAwait(false);

        //    var result = await _employeeRepository.DeleteEmployeeById(EmpIds).ConfigureAwait(false);

        //    if (result != 0)
        //    {
        //        responseMessage.StatusCode = Convert.ToInt32(HttpStatusCode.OK);
        //        responseMessage.StatusDescription = "Employee deleted sucesfully";
        //    }
        //    else
        //    {
        //        responseMessage.StatusCode = Convert.ToInt32(HttpStatusCode.BadRequest);
        //        responseMessage.StatusDescription = "Employee not found";
        //    }

        //    _logger.LogInformation($"Service-DeleteEmployeeById-Executing completed at {DateTime.UtcNow}");

        //    return responseMessage;
        //}

        ///// <summary>
        ///// GetAllEmployees
        ///// </summary>
        ///// <param name="includeDetails"></param>
        ///// <returns></returns>
        //public async Task<ResponseMessage> GetAllEmployees(bool includeDetails)
        //{
        //    _logger.LogInformation($"Service-GetAllEmployees-Executing started at {DateTime.UtcNow}");

        //    var employeesList = await _employeeRepository.GetAllEmployees(true).ConfigureAwait(false);

        //    if (employeesList.Any())
        //    {
        //        responseMessage.StatusCode = Convert.ToInt32(HttpStatusCode.OK);
        //        responseMessage.returnObj = EmployeeMapper.MapEmpToEmpListDto(employeesList);
        //    }
        //    else
        //    {
        //        _logger.LogInformation("No employee found");
        //        responseMessage.StatusCode = Convert.ToInt32(HttpStatusCode.NotFound);
        //    }

        //    _logger.LogInformation($"Service-GetAllEmployees-Executing completed at {DateTime.UtcNow}");

        //    return responseMessage;
        //}

        ///// <summary>
        ///// UpdateEmployee
        ///// </summary>
        ///// <param name="employeeModel"></param>
        ///// <returns></returns>
        //public async Task<ResponseMessage> UpdateEmployee(EmployeeModel employeeModel)
        //{
        //    _logger.LogInformation($"Service-UpdateEmployee-Executing started at {DateTime.UtcNow}");

        //    var emplResult = await _employeeRepository.GetEmployeeByName(employeeModel.Name, employeeModel.EmpId).ConfigureAwait(false);

        //    if (emplResult != null)
        //    {
        //        responseMessage.StatusCode = Convert.ToInt32(HttpStatusCode.Conflict);
        //        responseMessage.StatusDescription = "Employee name already exists";
        //        responseMessage.ErrorMessage = string.Format("Employee Name {0} already exists", employeeModel.Name);

        //        return responseMessage;
        //    }

        //    var employee = await _employeeRepository.GetEmployeeById(employeeModel.EmpId, true).ConfigureAwait(false);

        //    if (employee != null)
        //    {
        //        employee = employeeModel.MapempsDtosToUpdateEmps(employee);

        //        var result = await _employeeRepository.UpdateEmployee(employee);

        //        if (result != 0)
        //        {
        //            responseMessage.StatusCode = Convert.ToInt32(HttpStatusCode.OK);
        //            responseMessage.returnObj = employee.Name;
        //        }
        //        else
        //        {
        //            _logger.LogInformation("No employee found.");
        //            responseMessage.StatusCode = Convert.ToInt32(HttpStatusCode.NotFound);
        //            responseMessage.StatusDescription = "No Skill found.";
        //            responseMessage.ErrorMessage = $"Employee name {employeeModel.Name} not found";
        //        }
        //    }
        //    else
        //    {
        //        _logger.LogInformation("No employee found.");
        //        responseMessage.StatusCode = Convert.ToInt32(HttpStatusCode.NotFound);
        //        responseMessage.StatusDescription = "No Skill found.";
        //        responseMessage.ErrorMessage = $"Employee name {employeeModel.Name} not found.";
        //    }

        //    _logger.LogInformation($"Service-UpdateEmployee-Executing completed at {DateTime.UtcNow}");
        //    return responseMessage;
        //}
        public Task<ResponseMessage> CreateEmployeel(EmployeeModel employeeModel)
        {
            throw new NotImplementedException();
        }

        public Task<ResponseMessage> DeleteEmployeeById(Guid empIds)
        {
            throw new NotImplementedException();
        }

        public Task<ResponseMessage> GetAllEmployees(bool includeDetails)
        {
            throw new NotImplementedException();
        }

        public Task<ResponseMessage> UpdateEmployee(EmployeeModel employeeModel)
        {
            throw new NotImplementedException();
        }
    }
}
