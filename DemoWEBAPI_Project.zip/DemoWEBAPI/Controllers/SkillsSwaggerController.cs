﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using DemoCommon.Helper;
using DemoWEBAPI.Dto;
using DemoWEBAPI.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using DemoCommon.Extensions;

namespace DemoWEBAPI.Controllers
{
    [Route("DemoWEBAPI/Common")]
    [ApiController]
    public class SkillsSwaggerController : ControllerBase
    {
        private readonly ILogger _skillLogger;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ISkillService _skillService;
        private readonly IHostingEnvironment _env;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="env"></param>
        /// <param name="skillService"></param>
        /// <param name="logger"></param>
        /// <param name="httpContextAccessor"></param>
        public SkillsSwaggerController(IHostingEnvironment env, ISkillService skillService, ILogger<SkillsController> logger, IHttpContextAccessor httpContextAccessor)
        {
            _skillLogger = logger;
            _httpContextAccessor = httpContextAccessor;
            _skillService = skillService;
            _env = env;
            CheckArguments();
        }

        /// <summary>
        /// GetAllSkills
        /// </summary>
        /// <returns></returns>
        [HttpGet("GetAllSkills", Name = nameof(GetAllSkills))]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        [Authorize(PermissionUserRoles.SkillsView)]
        public async Task<ActionResult> GetAllSkills()
        {
            try
            {
                using (_skillLogger.BeginScope($"API-GetAllSkills-Initiated at{DateTime.UtcNow}"))
                {
                    _skillLogger.LogInformation("API-GetAllSkills-Getting list of skills");

                    var result = await _skillService.GetAllSkills().ConfigureAwait(false);

                    if (result.StatusCode == Convert.ToInt32(HttpStatusCode.OK))
                    {
                        _skillLogger.LogInformation("Skills found", "API-GetAllSkills");
                        return StatusCode(result.StatusCode, result.returnObj);
                    }
                    else
                    {
                        _skillLogger.LogInformation("Skills not found", "API-GetAllSkills");
                        return StatusCode(result.StatusCode);
                    }
                }
            }
            catch (Exception ex)
            {
                _skillLogger.LogError
                   (ex,
                    $"API-GetAllSkills-Exception {DateTime.UtcNow}"
                  );

                return StatusCode((int)HttpStatusCode.BadRequest,
                     (_env.IsDevelopment()) ? ex.ToString() : "An error occured while processing GetAllSkills");
            }
        }

        /// <summary>
        /// CreateSkill
        /// </summary>
        /// <param name="skillDto"></param>
        /// <returns></returns>
        [HttpPost("CreateSkill", Name = nameof(CreateSkill))]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [ProducesResponseType(409)]
        [Authorize(PermissionUserRoles.SkillsEdit)]
        public async Task<ActionResult> CreateSkill([FromBody] SkillModel skillDto)
        {
            try
            {
                using (_skillLogger.BeginScope($"API-CreateSkill-Initiated at {DateTime.UtcNow}"))
                {
                    var result = await _skillService.CreateSkill(skillDto).ConfigureAwait(false);

                    if (result.StatusCode == Convert.ToInt32(HttpStatusCode.Created))
                    {
                        _skillLogger.LogInformation($"API-CreateSkill-Completed at {DateTime.UtcNow}");
                    }
                    else
                    {
                        _skillLogger.LogInformation($"API-CreateSkill-Not Completed at {DateTime.UtcNow}");
                    }

                    return StatusCode(result.StatusCode, result);
                }
            }
            catch (Exception ex)
            {
                _skillLogger.LogError
                   (ex,
                    $"API-CreateSkill-Exception {DateTime.UtcNow}"
                  );

                return StatusCode((int)HttpStatusCode.BadRequest,
                    (_env.IsDevelopment()) ? ex.ToString() : "An error occured while processing CreateSkill");
            }
        }

        /// <summary>
        /// UpdateSkill
        /// </summary>
        /// <param name="skillDto"></param>
        /// <returns></returns>
        [HttpPut("UpdateSkill", Name = nameof(UpdateSkill))]
        [ProducesResponseType(204)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        [Authorize(PermissionUserRoles.SkillsEdit)]
        public async Task<ActionResult> UpdateSkill([FromBody] SkillModel skillDto)
        {
            try
            {
                using (_skillLogger.BeginScope($"API-UpdateSkill-Initiated {DateTime.UtcNow}"))
                {
                    var result = await _skillService.UpdateSkill(skillDto).ConfigureAwait(false);

                    if (result.StatusCode == Convert.ToInt32(HttpStatusCode.NoContent))
                    {
                        _skillLogger.LogInformation($"API-UpdateSkill-Completed {DateTime.UtcNow}");
                    }
                    else
                    {
                        _skillLogger.LogInformation($"API-UpdateSkill-Not Completed {DateTime.UtcNow}");

                    }
                    return StatusCode(result.StatusCode, result);
                }
            }
            catch (Exception ex)
            {
                _skillLogger.LogError
                   (ex,
                    $"API-UpdateSkill-Exception {DateTime.UtcNow}"
                  );

                return StatusCode((int)HttpStatusCode.BadRequest,
                    (_env.IsDevelopment()) ? ex.ToString() : "An error occured while processing UpdateSkill");
            }
        }

        /// <summary>
        /// TODO: 
        /// Return multiple results on skill deletion failure or NOTFOUND
        /// </summary>
        /// <param name="skillIds"></param>
        /// <returns></returns>
        [HttpPut("DeleteSkillByIds", Name = nameof(DeleteSkillByIds))]
        [ProducesResponseType(204)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        [Authorize(PermissionUserRoles.SkillsEdit)]
        public async Task<ActionResult> DeleteSkillByIds([FromBody] Guid skillIds)
        {
            try
            {
                using (_skillLogger.BeginScope($"API-DeleteSkillByMultipleIds-Initiated {DateTime.UtcNow}"))
                {

                    var _statusCode = HttpStatusCode.NotFound;

                    if (skillIds != Guid.Empty)
                    {
                        var result = await _skillService.DeleteSkillById(skillIds).ConfigureAwait(false);
                        return StatusCode(result.StatusCode, result);
                    }

                    _skillLogger.LogInformation($"API-DeleteSkillByMultipleIds-Completed {DateTime.UtcNow}");

                    return StatusCode(Convert.ToInt32(_statusCode));
                }
            }
            catch (Exception ex)
            {
                _skillLogger.LogError
                   (ex,
                    $"API-DeleteSkillByMultipleIds-Exception {DateTime.UtcNow}"
                  );

                return StatusCode((int)HttpStatusCode.BadRequest,
                    (_env.IsDevelopment()) ? ex.ToString() : "An error occured while processing DeleteSkillByMultipleIds");
            }
        }

        [HttpGet("GetSkillByIds", Name = nameof(GetSkillByIds))]
        [ProducesResponseType(204)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        [Authorize(PermissionUserRoles.SkillsView)]
        public async Task<ActionResult> GetSkillByIds([FromBody] Guid skillIds)
        {
            try
            {
                using (_skillLogger.BeginScope($"API-GetSkillByIds-Initiated {DateTime.UtcNow}"))
                {
                    var _statusCode = HttpStatusCode.NotFound;

                    if (skillIds != Guid.Empty)
                    {
                        var result = await _skillService.GetSkillById(skillIds).ConfigureAwait(false);
                        return StatusCode(result.StatusCode, result);
                    }

                    _skillLogger.LogInformation($"API-GetSkillByIds-Completed {DateTime.UtcNow}");

                    return StatusCode(Convert.ToInt32(_statusCode));
                }
            }
            catch (Exception ex)
            {
                _skillLogger.LogError
                   (ex,
                    $"API-GetSkillByIds-Exception {DateTime.UtcNow}"
                  );

                return StatusCode((int)HttpStatusCode.BadRequest,
                    (_env.IsDevelopment()) ? ex.ToString() : "An error occured while processing GetSkillByIds");
            }
        }

        /// <summary>
        /// CheckArguments
        /// </summary>
        private void CheckArguments()
        {
            _skillService.CheckArgumentIsNull(nameof(_skillService));
            _skillLogger.CheckArgumentIsNull(nameof(_skillLogger));
            _httpContextAccessor.CheckArgumentIsNull(nameof(_httpContextAccessor));
            _env.CheckArgumentIsNull(nameof(_env));
        }
    }
}