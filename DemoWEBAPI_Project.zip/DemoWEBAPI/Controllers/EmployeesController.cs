﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using DemoCommon.Helper;
using DemoCommon.Models;
using DemoWEBAPI.IServices;
using DemoWEBAPI.Repository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace DemoWEBAPI.Controllers
{
    //[Route("api/[controller]")]
   // [ApiController]
    public class EmployeesController : ControllerBase
    {

        private readonly IEmployeesRepository _employeesRepository;

        public EmployeesController(IEmployeesRepository employeesRepository)
        {
            _employeesRepository = employeesRepository;
        }
        [HttpGet]
        [Route("api/Employees/Get")]
        public async Task<IEnumerable<Employees>> Get()
        {
            return await _employeesRepository.GetEmployees();
        }

        [HttpPost]
        [Route("api/Employees/Create")]
        public async Task CreateAsync([FromBody]Employees employee)
        {
            if (ModelState.IsValid)
            {
                await _employeesRepository.Add(employee);
            }
        }

        [HttpGet]
        [Route("api/Employees/Details/{id}")]
        public async Task<Employees> Details(string id)
        {
            var result = await _employeesRepository.GetEmployee(id);
            return result;
        }

        [HttpPut]
        [Route("api/Employees/Edit")]
        public async Task EditAsync([FromBody]Employees employee)
        {
            if (ModelState.IsValid)
            {
                await _employeesRepository.Update(employee);
            }
        }

        [HttpDelete]
        [Route("api/Employees/Delete/{id}")]
        public async Task DeleteConfirmedAsync(string id)
        {
            await _employeesRepository.Delete(id);
        }
    }
}